<?php
    define('HOST','localhost');
    define('USER','root');
    define('PASS','');
    define('BASE','produto_desafio');

    $conn = new MySQLi(HOST,USER,PASS,BASE);