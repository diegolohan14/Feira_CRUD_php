CREATE TABLE produto (
  id_produto INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  nome_produto VARCHAR(100) NULL,
  peso_liquido_produto VARCHAR(255) NULL,
  validade_produto DATE NULL,
  lote_produto VARCHAR(100) NULL,
  porcao_produto VARCHAR(1000) NULL,
  valor_energetico_produto VARCHAR(1000) NULL,
  carboidratos_produto VARCHAR(255) NULL,
  proteinas_produto VARCHAR(100) NULL,
  gorduras_totais_produto VARCHAR(100) NULL,
  PRIMARY KEY(id_produto)
);


