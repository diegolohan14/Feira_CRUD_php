<h1>Editar produtos</h1>
<?php
    $sql = "SELECT * FROM produto WHERE id_produto=".$_REQUEST["id_produto"];

    $res = $conn->query($sql) or die($conn->error);

    $row = $res->fetch_object();
?>
<form action="?page=salvar-produtos" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_produto" value="<?php print $row->id_produto; ?>">
    <div class="mb-3">
        <h5>Informações Gerais</h5>
    <div class="mb-3">
    <div class="mb-3">
        <label>Nome do Produto</label>
        <input type="text" name="nome_produto" class="form-control" value="<?php print $row->nome_produto; ?>">
    </div>
    <div class="mb-3">
        <label>Peso Líquido (g)</label>
        <input type="float" name="peso_liquido_produto" class="form-control" value="<?php print $row->peso_liquido_produto; ?>">
    </div>
    <div class="mb-3">
        <label>Validade</label>
        <input type="date" name="validade_produto" class="form-control" value="<?php print $row->validade_produto; ?>">
    </div>
    <div class="mb-3">
        <label>Lote</label>
        <input type="int" name="lote_produto" class="form-control" value="<?php print $row->lote_produto; ?>">
    </div>
    <div class="mb-3">
        <h5>Valores nutricionais</h5>
    <div class="mb-3">
        <label>Porção (g)</label>
        <input type="float" name="porcao_produto" class="form-control" value="<?php print $row->porcao_produto; ?>">
    </div>
    <div class="mb-3">
        <label>Valor energético (kcal)</label>
        <input type="float" name="valor_energetico_produto" class="form-control" value="<?php print $row->valor_energetico_produto; ?>">
    </div>
    <div class="mb-3">
        <label>Carboidratos (g)</label>
        <input type="float" name="carboidratos_produto" class="form-control" value="<?php print $row->carboidratos_produto; ?>">
    </div>
    <div class="mb-3">
        <label>Proteínas (g)</label>
        <input type="float" name="proteinas_produto" class="form-control" value="<?php print $row->proteinas_produto; ?>">
    </div>
    <div class="mb-3">
        <label>Gorduras Totais (g)</label>
        <input type="float" name="gorduras_totais_produto" class="form-control" value="<?php print $row->gorduras_totais_produto; ?>">
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-success">Enviar</button>
    </div>
</form>