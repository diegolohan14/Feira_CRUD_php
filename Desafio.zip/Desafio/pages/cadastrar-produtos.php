<h1>Cadastrar Produtos</h1>
<form action="?page=salvar-produtos" method="POST">
    <input type="hidden" name="acao" value="cadastrar">
    <div class="mb-3">
        <h5>Informações Gerais</h5>
    <div class="mb-3">
    <div class="mb-3">
        <label>Nome do Produto</label>
        <input type="text" name="nome_produto" class="form-control">
    </div>
    <div class="mb-3">
        <label>Peso Líquido (g)</label>
        <input type="float" name="peso_liquido_produto" class="form-control">
    </div>
    <div class="mb-3">
        <label>Validade</label>
        <input type="date" name="validade_produto" class="form-control">
    </div>
    <div class="mb-3">
        <label>Lote</label>
        <input type="int" name="lote_produto" class="form-control">
    </div>
    <div class="mb-3">
        <h5>Valores nutricionais</h5>
    <div class="mb-3">
        <label>Porção (g)</label>
        <input type="float" name="porcao_produto" class="form-control">
    </div>
    <div class="mb-3">
        <label>Valor energético (kcal)</label>
        <input type="float" name="valor_energetico_produto" class="form-control">
    </div>
    <div class="mb-3">
        <label>Carboidratos (g)</label>
        <input type="float" name="carboidratos_produto" class="form-control">
    </div>
    <div class="mb-3">
        <label>Proteínas (g)</label>
        <input type="float" name="proteinas_produto" class="form-control">
    </div>
    <div class="mb-3">
        <label>Gorduras Totais (g)</label>
        <input type="float" name="gorduras_totais_produto" class="form-control">
    </div>
    <div class="mb-3">
        <button type="submit" class="btn btn-success">Enviar</button>
    </div>
</form>