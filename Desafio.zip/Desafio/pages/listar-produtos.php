<h1>Lista de produtos</h1>
<?php
    $sql = "SELECT * FROM produto";

    $res = $conn->query($sql) or die($conn->error);

    $qtd = $res->num_rows;

    print "<p>Encontrou <b>".$qtd."</b> resultado(s)</p>";

    if($qtd > 0){
        print "<table class='table table-striped table-hover table-bordered'>";
            print "<tr>";
            print "<th>#</th>";
            print "<th>Nome do Produto</th>";
            print "<th>Peso Líquido (g)</th>";
            print "<th>Validade</th>";
            print "<th>Lote</th>";
            print "<th>Porção (g)</th>";
            print "<th>Valor enegético (kcal)</th>";
            print "<th>Carboidratos (g)</th>";
            print "<th>Proteínas (g)</th>";
            print "<th>Gorduras Totais (g)</th>";
            print "<th>Ações</th>";
            print "</tr>";
        while($row = $res->fetch_object()){
            print "<tr>";
            print "<td>".$row->id_produto."</td>";
            print "<td>".$row->nome_produto."</td>";
            print "<td>".$row->peso_liquido_produto."</td>";
            print "<td>".$row->validade_produto."</td>";
            print "<td>".$row->lote_produto."</td>";
            print "<td>".$row->porcao_produto."</td>";
            print "<td>".$row->valor_energetico_produto."</td>";
            print "<td>".$row->carboidratos_produto."</td>";
            print "<td>".$row->proteinas_produto."</td>";
            print "<td>".$row->gorduras_totais_produto."</td>";
            print "<td>
                        <button class='btn btn-dark' onclick=\"location.href='?page=editar-produtos&id_produto=".$row->id_produto."';\">Editar</button>

                        <button class='btn btn-danger' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar-produtos&acao=excluir&id_produto=".$row->id_produto."';}else{false;}\">Excluir</button>
                    </td>";
            print "</tr>";
        }
        print "</table>";
    }else{
        print "<div class='alert alert-danger'>Não encontrou resultados.</div>";
    }
?>