<?php
    switch ($_REQUEST["acao"]){
        case 'cadastrar':
            $nome = $_POST["nome_produto"];
            $valor_energetico = $_POST["valor_energetico_produto"];
            $carboidratos = $_POST["carboidratos_produto"];
            $proteinas = $_POST["proteinas_produto"];
            $gorduras_totais = $_POST["gorduras_totais_produto"];
            $peso_liquido = $_POST["peso_liquido_produto"];
            $validade = $_POST["validade_produto"];
            $lote = $_POST["lote_produto"];
            $porcao = $_POST["porcao_produto"];

            $sql = "INSERT INTO produto (
                        nome_produto, 
                        valor_energetico_produto, 
                        carboidratos_produto, 
                        proteinas_produto, 
                        gorduras_totais_produto, 
                        peso_liquido_produto, 
                        validade_produto, 
                        lote_produto, 
                        porcao_produto
                    ) VALUES (
                        '{$nome}',
                        '{$valor_energetico}',
                        '{$carboidratos}',
                        '{$proteinas}',
                        '{$gorduras_totais}',
                        '{$peso_liquido}',
                        '{$validade}',
                        '{$lote}',
                        '{$porcao}'
                    )";

            $res = $conn->query($sql) or die($conn->error);

            if($res==true){
                print "<script>alert('Cadastrou com sucesso!')</script>";
                print "<script>
                    location.href='?page=listar-produtos';</script>";
            }else{
                print "<script>alert('Não foi possível cadastrar!')</script>";
                print "<script>
                    location.href='?page=listar-produtos';</script>";
            }
            break;

        case 'editar':
            $nome = $_POST["nome_produto"];
            $valor_energetico = $_POST["valor_energetico_produto"];
            $carboidratos = $_POST["carboidratos_produto"];
            $proteinas = $_POST["proteinas_produto"];
            $gorduras_totais = $_POST["gorduras_totais_produto"];
            $peso_liquido = $_POST["peso_liquido_produto"];
            $validade = $_POST["validade_produto"];
            $lote = $_POST["lote_produto"];
            $porcao = $_POST["porcao_produto"];

            $sql = "UPDATE produto SET nome_produto='{$nome}', valor_energetico_produto='{$valor_energetico}', carboidratos_produto='{$carboidratos}', proteinas_produto='{$proteinas}', gorduras_totais_produto='{$gorduras_totais}', peso_liquido_produto='{$peso_liquido}', validade_produto='{$validade}', lote_produto='{$lote}', porcao_produto='{$porcao}' WHERE id_produto=".$_POST["id_produto"];

            $res = $conn->query($sql) or die($conn->error);

            if($res==true){
                print "<script>alert('Editou com sucesso!')</script>";
                print "<script>
                    location.href='?page=listar-produtos';</script>";
            }else{
                print "<script>alert('Não foi possível editar!')</script>";
                print "<script>
                    location.href='?page=listar-produtos';</script>";
            }
            break;

        case 'excluir':
            $sql = "DELETE FROM produto WHERE id_produto=".$_REQUEST["id_produto"];
            
            $res = $conn->query($sql) or die($conn->error);

            if($res==true){
                print "<script>alert('Excluiu com sucesso!')</script>";
                print "<script>
                    location.href='?page=listar-produtos';</script>";
            }else{
                print "<script>alert('Não foi possível excluir!')</script>";
                print "<script>
                    location.href='?page=listar-produtos';</script>";
            }
            break;
            
    }